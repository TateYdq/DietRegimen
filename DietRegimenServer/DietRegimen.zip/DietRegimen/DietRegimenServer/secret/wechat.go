package secret
const (
	AppID = "wx88562f9e9cb98f7f"
	AppSecret = "467ff3549e29d2d778fa380c05e33a1e"
)
