package helper


func VerifyAdminToken()(success bool){
	return true
}