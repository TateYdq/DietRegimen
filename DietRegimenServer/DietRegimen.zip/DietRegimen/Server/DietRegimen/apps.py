from django.apps import AppConfig


class DietregimenConfig(AppConfig):
    name = 'DietRegimen'
