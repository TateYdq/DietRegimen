var foodKindID = 10001;
var foodListID = 10002;

module.exports = {
  foodKindID: foodKindID,
  foodListID: foodListID
}