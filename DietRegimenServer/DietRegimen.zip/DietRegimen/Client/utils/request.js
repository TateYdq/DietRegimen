/*
此页面为发起request请求页面
*/
domain='api.ydq6.com'
urlPrefix=domain+'/DietRegiment/client'